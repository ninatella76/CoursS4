package fr.winonamoreau.multiplicatraining;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Multiplication extends AppCompatActivity {

    int a, b, score=0;
    EditText edit;
    TextView operation, scoreTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multiplication);
        scoreTxt  = findViewById(R.id.score);
        operation = findViewById(R.id.operation);
        edit      = findViewById(R.id.defaultValue);
        remplir();
    }

    public void remplir(){
        edit.getText().clear();
        edit.setText("");
        a = (int)(Math.random() * 9);
        b = (int)(Math.random() * 9);

        operation.setText(a + " x " + b + " = ");
    }

    public void verify(View v){

        if (!(edit.getText().toString()).equals("")){
        if( a*b == Integer.parseInt(edit.getText().toString())){
            operation = findViewById(R.id.operation);
            remplir();
            Toast.makeText(Multiplication.this,"Réponse correct", Toast.LENGTH_SHORT).show();
            score++;
            if (score < 0)
                scoreTxt.setTextColor(Color.RED);
            else
                scoreTxt.setTextColor(Color.GREEN);
            scoreTxt.setText("" + score);

        }
        else {
            Toast.makeText(Multiplication.this,"Réponse incorrect", Toast.LENGTH_SHORT).show();
            edit.getText().clear();
            score--;
            scoreTxt.setTextColor(Color.RED);

            scoreTxt.setText("" + score);
        }}
    }
}
